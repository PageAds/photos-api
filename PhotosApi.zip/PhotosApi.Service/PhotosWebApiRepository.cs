﻿using Newtonsoft.Json;
using PhotosApi.Core.Interfaces;
using PhotosApi.Core.Models;
using PhotosApi.Service.Interfaces;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace PhotosApi.Service
{
    public class PhotosWebApiRepository : IRepository<Photo>
    {
        private readonly IHttpClientFactory httpClientFactory;
        private readonly IConfiguration configuration;

        public PhotosWebApiRepository(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            this.httpClientFactory = httpClientFactory;
            this.configuration = configuration;
        }

        public async Task<IEnumerable<Photo>> GetAsync()
        {
            var client = this.httpClientFactory.CreateClient();
            var response = await client.GetAsync(this.configuration.PhotoWebApiUrl);
            response.EnsureSuccessStatusCode();
            var responseBody = await response.Content.ReadAsStringAsync();
           
            return JsonConvert.DeserializeObject<IEnumerable<Photo>>(responseBody);
        }
    }
}
