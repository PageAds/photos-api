﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PhotosApi.Core.Interfaces;
using PhotosApi.Core.Models;

namespace PhotosApi.Service
{
    public class AlbumsService : IAlbumsService
    {
        private readonly IRepository<Photo> photosRepository;
        private readonly IRepository<Album> albumsRepository;

        public AlbumsService(IRepository<Photo> photosRepository, IRepository<Album> albumsRepository)
        {
            this.photosRepository = photosRepository;
            this.albumsRepository = albumsRepository;
        }

        public async Task<IEnumerable<AlbumDto>> GetByUser(int userId)
        {
            var photos = await this.photosRepository.GetAsync();
            var albums = await this.albumsRepository.GetAsync();

            var photosByAlbumId = photos
                .GroupBy(p => p.AlbumId);

            var albumDto = albums
                .Where(a => a.UserId == userId)
                .Select(a => new AlbumDto()
                {
                    Id = a.Id,
                    Photos = photosByAlbumId.SingleOrDefault(p => p.Key == a.Id),
                    Title = a.Title,
                    UserId = a.UserId
                });

            return albumDto;
        }
    }
}
