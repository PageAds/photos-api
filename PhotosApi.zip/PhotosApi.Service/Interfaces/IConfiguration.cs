﻿namespace PhotosApi.Service.Interfaces
{
    public interface IConfiguration
    {
        string AlbumWebApiUrl { get; }

        string PhotoWebApiUrl { get; }
    }
}
