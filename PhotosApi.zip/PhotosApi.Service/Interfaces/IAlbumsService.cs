﻿using PhotosApi.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PhotosApi.Core.Interfaces
{
    public interface IAlbumsService
    {
        Task<IEnumerable<AlbumDto>> GetByUser(int userId);
    }
}
