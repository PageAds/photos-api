﻿using PhotosApi.Service.Interfaces;

namespace PhotosApi.Service
{
    public class HardcodedConfiguration : IConfiguration
    {
        public string AlbumWebApiUrl => "http://jsonplaceholder.typicode.com/albums";

        public string PhotoWebApiUrl => "http://jsonplaceholder.typicode.com/photos";
    }
}
