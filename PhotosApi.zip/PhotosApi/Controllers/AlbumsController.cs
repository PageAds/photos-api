﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PhotosApi.Core.Interfaces;
using PhotosApi.Core.Models;

namespace PhotosApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumsController : ControllerBase
    {
        private readonly IAlbumsService albumsService;

        public AlbumsController(IAlbumsService albumsService)
        {
            this.albumsService = albumsService;
        }

        [HttpGet]
        public async Task<ActionResult<AlbumDto>> GetByUser([FromQuery] int userId)
        {
            var albumDto = await this.albumsService.GetByUser(userId);

            return new OkObjectResult(albumDto);
        }
    }
}
