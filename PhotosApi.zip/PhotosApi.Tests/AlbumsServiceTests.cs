﻿using NSubstitute;
using PhotosApi.Core.Interfaces;
using PhotosApi.Core.Models;
using PhotosApi.Service;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace PhotosApi.Tests
{
    public class AlbumsServiceTests
    {
        [Fact]
        public async void GetByUser_WhenCalled_PhotoAndAlbumRepositoryAreCalledOnceEach()
        {
            // Arrange
            var photosRepository = Substitute.For<IRepository<Photo>>();
            photosRepository.GetAsync().Returns(Enumerable.Empty<Photo>());

            var albumsRepository = Substitute.For<IRepository<Album>>();
            albumsRepository.GetAsync().Returns(Enumerable.Empty<Album>());

            var albumsService = new AlbumsService(photosRepository, albumsRepository);

            // Act
            var albumDto = await albumsService.GetByUser(1);

            // Assert
            await photosRepository.Received(1).GetAsync();
            await albumsRepository.Received(1).GetAsync();
        }

        [Fact]
        public async void GetByUser_WhenCalledWhereASingleAlbumWithTwoPhotosForAUserExists_SingleAlbumWithTwoPhotosAreReturned()
        {
            // Arrange
            var userId = 1;
            var photosRepository = Substitute.For<IRepository<Photo>>();

            var photos = new List<Photo>()
            {
                DummyPhoto(1, 1),
                DummyPhoto(2, 1)
            };

            photosRepository.GetAsync().Returns(photos);

            var albumsRepository = Substitute.For<IRepository<Album>>();
            var albums = new List<Album>()
            {
                DummyAlbum(1, userId)
            };

            albumsRepository.GetAsync().Returns(albums);

            var albumsService = new AlbumsService(photosRepository, albumsRepository);

            // Act
            var albumDto = await albumsService.GetByUser(userId);

            // Assert
            var albumDtoList = albumDto.ToList();
            Assert.True(albumDtoList.Count == 1);
            Assert.True(albumDtoList[0].Id == 1);
            Assert.True(albumDtoList[0].Title == "Album1");
            Assert.True(albumDtoList[0].UserId == userId);

            var photosList = albumDtoList[0].Photos.ToList();
            Assert.True(photosList.Count == 2);
            Assert.True(photosList[0].AlbumId == 1);
            Assert.True(photosList[1].AlbumId == 1);
            Assert.Contains(photosList, p => p.Id == 1);
            Assert.Contains(photosList, p => p.Id == 2);
            Assert.Contains(photosList, p => p.ThumbnailUrl == "ThumbnailUrlPhoto1");
            Assert.Contains(photosList, p => p.ThumbnailUrl == "ThumbnailUrlPhoto2");
            Assert.Contains(photosList, p => p.Title == "Album1Photo1");
            Assert.Contains(photosList, p => p.Title == "Album1Photo2");
            Assert.Contains(photosList, p => p.Url == "UrlPhoto1");
            Assert.Contains(photosList, p => p.Url == "UrlPhoto2");
        }

        [Fact]
        public async void GetByUser_WhenCalledWhereTwoAlbumsForDifferentUsersExists_AlbumCorrespondingToUserRequestedIsReturned()
        {
            // Arrange
            var photosRepository = Substitute.For<IRepository<Photo>>();

            var photos = new List<Photo>()
            {
                DummyPhoto(1, 1),
                DummyPhoto(2, 1),
                DummyPhoto(3, 2),
                DummyPhoto(4, 2)
            };

            photosRepository.GetAsync().Returns(photos);

            var albumsRepository = Substitute.For<IRepository<Album>>();
            var albums = new List<Album>()
            {
                DummyAlbum(1, 1),
                DummyAlbum(2, 2)
            };

            albumsRepository.GetAsync().Returns(albums);

            var albumsService = new AlbumsService(photosRepository, albumsRepository);

            // Act
            var albumDto = await albumsService.GetByUser(2);

            // Assert
            var albumDtoList = albumDto.ToList();
            Assert.True(albumDtoList.Count == 1);
            Assert.True(albumDtoList[0].Id == 2);
            Assert.True(albumDtoList[0].Title == "Album2");
            Assert.True(albumDtoList[0].UserId == 2);

            var photosList = albumDtoList[0].Photos.ToList();
            Assert.True(photosList.Count == 2);
            Assert.True(photosList[0].AlbumId == 2);
            Assert.True(photosList[1].AlbumId == 2);
            Assert.Contains(photosList, p => p.Id == 3);
            Assert.Contains(photosList, p => p.Id == 4);
            Assert.Contains(photosList, p => p.ThumbnailUrl == "ThumbnailUrlPhoto3");
            Assert.Contains(photosList, p => p.ThumbnailUrl == "ThumbnailUrlPhoto4");
            Assert.Contains(photosList, p => p.Title == "Album2Photo3");
            Assert.Contains(photosList, p => p.Title == "Album2Photo4");
            Assert.Contains(photosList, p => p.Url == "UrlPhoto3");
            Assert.Contains(photosList, p => p.Url == "UrlPhoto4");
        }

        [Fact]
        public async void GetByUser_WhenCalledByAUserWhichHasNoAlbums_EmptyResultReturned()
        {
            // Arrange
            var photosRepository = Substitute.For<IRepository<Photo>>();

            var photos = new List<Photo>()
            {
                DummyPhoto(1, 1),
                DummyPhoto(2, 1)
            };

            photosRepository.GetAsync().Returns(photos);

            var albumsRepository = Substitute.For<IRepository<Album>>();
            var albums = new List<Album>()
            {
                DummyAlbum(1, 1)
            };

            albumsRepository.GetAsync().Returns(albums);

            var albumsService = new AlbumsService(photosRepository, albumsRepository);

            // Act
            var albumDto = await albumsService.GetByUser(2);

            // Assert
            Assert.Empty(albumDto);
        }

        private static Photo DummyPhoto(int photoId, int albumId)
        {
            return new Photo()
            {
                AlbumId = albumId,
                Id = photoId,
                ThumbnailUrl = $"ThumbnailUrlPhoto{photoId}",
                Title = $"Album{albumId}Photo{photoId}",
                Url = $"UrlPhoto{photoId}"
            };
        }

        private static Album DummyAlbum(int albumId, int userId)
        {
            return new Album()
            {
                Id = albumId,
                Title = $"Album{albumId}",
                UserId = userId
            };
        }
    }
}
